async function checkAccess() {
  const user = localStorage.getItem("user");
  const deviceId = localStorage.getItem("deviceId");

  if (!user || !deviceId) {
    window.location.href = "login.html";
    return;
  }

  const res = await fetch("https://your-server.com/validate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: user, deviceId })
  });

  const data = await res.json();

  if (data.status === "valid" || data.status === "authorized") {
    console.log("Access granted");
  } else {
    const key = prompt("Your trial expired. Enter license key:");
    const keyRes = await fetch("https://your-server.com/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: user, deviceId, key })
    });

    const result = await keyRes.json();

    if (result.status === "authorized") {
      alert("✅ Key accepted.");
    } else {
      alert("⛔ Invalid key. Logging out.");
      localStorage.clear();
      window.location.href = "login.html";
    }
  }
}
