document.addEventListener("DOMContentLoaded", function () {
  // Printer Selection logic
  const modelOptions = {
    hp: ['HP Model A', 'HP Model B'],
    canon: ['Canon Model X', 'Canon Model Y'],
    epson: ['Epson Model 1', 'Epson Model 2']
  };

  const brandSelect = document.getElementById('brand');
  const modelSelect = document.getElementById('model');

  brandSelect.addEventListener('change', function() {
    const selectedBrand = this.value;
    const models = modelOptions[selectedBrand] || [];

    // Clear current models
    modelSelect.innerHTML = '<option value="">Select Model</option>';

    // Add new models
    models.forEach(model => {
      const option = document.createElement('option');
      option.value = model;
      option.textContent = model;
      modelSelect.appendChild(option);
    });
  });

  // Form Submission logic
  document.getElementById('printerForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const selectedOS = document.getElementById('os').value;
    const selectedBrand = document.getElementById('brand').value;
    const selectedModel = document.getElementById('model').value;

    if (!selectedOS || !selectedBrand || !selectedModel) {
      alert('Please select all options!');
      return;
    }

    let downloadLink = '';
    if (selectedOS === 'windows') {
      downloadLink = `https://www.example.com/drivers/${selectedBrand}_${selectedModel}_windows.exe`;
    } else if (selectedOS === 'macos') {
      downloadLink = `https://www.example.com/drivers/${selectedBrand}_${selectedModel}_mac.dmg`;
    } else if (selectedOS === 'linux') {
      downloadLink = `https://www.example.com/drivers/${selectedBrand}_${selectedModel}_linux.tar.gz`;
    }

    // Redirect to the download link
    window.location.href = downloadLink; 
  });
});
